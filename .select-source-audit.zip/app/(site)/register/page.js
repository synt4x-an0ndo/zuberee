import { Suspense } from "react";
import RegisterForm from "./RegisterForm";

export const metadata = { title: "Create account" };

export default function RegisterPage() {
  return (
    <Suspense fallback={<div className="container section" />}>
      <RegisterForm />
    </Suspense>
  );
}
